from distutils.core import setup

setup(name='baiyu',vwesion='1.0',description='baiyu module',author='baiyu',py_modules=['suba.a','suba.b','subb.a','subb.b'])
